"""Add the compiled original Studyroom framework to a LOCAL Gizmo IPA copy.

The Gizmo IPA is never used by the cloud build. Output requires re-signing.
"""
import argparse
import hashlib
import json
import plistlib
import struct
import zipfile
from pathlib import Path

LIBRARY = '@executable_path/Frameworks/StudyroomTools.framework/StudyroomTools'


def commands(data):
    if data[:4] != bytes.fromhex('cffaedfe'):
        raise ValueError('Expected a thin ARM64 Mach-O executable')
    if struct.unpack_from('<I', data, 4)[0] != 0x100000C:
        raise ValueError('Expected ARM64 CPU type')
    count, size = struct.unpack_from('<II', data, 16)
    cursor = 32
    result = []
    for _ in range(count):
        cmd, length = struct.unpack_from('<II', data, cursor)
        if length < 8 or length % 8 or cursor + length > 32 + size:
            raise ValueError('Invalid Mach-O load command')
        result.append((cmd, bytes(data[cursor:cursor + length])))
        cursor += length
    if cursor != 32 + size:
        raise ValueError('Load command size mismatch')
    return result, size


def add_library(data):
    old, old_size = commands(data)
    sections = []
    for cmd, block in old:
        if cmd in (12, 0x80000018):
            offset = struct.unpack_from('<I', block, 8)[0]
            if block[offset:].split(b'\0')[0].decode() == LIBRARY:
                raise ValueError('This copy already contains the add-on')
        if cmd == 0x19:
            count = struct.unpack_from('<I', block, 64)[0]
            for index in range(count):
                offset = struct.unpack_from('<I', block, 72 + index * 80 + 48)[0]
                if offset:
                    sections.append(offset)
    first = min(sections)
    kept = [(cmd, block) for cmd, block in old if cmd != 0x1D]
    name = LIBRARY.encode() + b'\0'
    length = (24 + len(name) + 7) & ~7
    extra = struct.pack('<6I', 12, length, 24, 0, 0x10000, 0x10000)
    extra += name + bytes(length - 24 - len(name))
    combined = b''.join(block for _, block in kept) + extra
    if 32 + len(combined) > first:
        raise ValueError('Insufficient Mach-O header padding')
    end = max(32 + old_size, 32 + len(combined))
    # Do not overwrite any original non-padding data.
    if end > 32 + old_size and any(data[32 + old_size:end]):
        raise ValueError('Header padding is not empty')
    result = bytearray(data)
    struct.pack_into('<II', result, 16, len(kept) + 1, len(combined))
    result[32:end] = combined + bytes(end - 32 - len(combined))
    parsed, _ = commands(result)
    assert parsed == kept + [(12, extra)]
    assert result[first:] == data[first:]
    assert len(result) == len(data)
    return bytes(result)


def package(source, framework, output):
    if source.resolve() == output.resolve():
        raise ValueError('Output must not overwrite the original')
    root = 'Payload/Gizmo.app/'
    main = root + 'Gizmo'
    with zipfile.ZipFile(source) as original, zipfile.ZipFile(framework) as addon:
        info = plistlib.loads(original.read(root + 'Info.plist'))
        if info['CFBundleIdentifier'] != 'io.gonative.ios.xqdyad':
            raise ValueError('Unexpected app identifier')
        names = addon.namelist()
        required = {'StudyroomTools.framework/StudyroomTools',
                    'StudyroomTools.framework/Info.plist',
                    'StudyroomTools.framework/Web/index.html',
                    'StudyroomTools.framework/Web/app.js',
                    'StudyroomTools.framework/Web/core.js',
                    'StudyroomTools.framework/Web/style.css'}
        if not required.issubset(names):
            raise ValueError('Incomplete framework archive')
        for name in names:
            if name.startswith('/') or '..' in Path(name).parts or not name.startswith('StudyroomTools.framework/'):
                raise ValueError('Unexpected framework archive path')
        commands(addon.read('StudyroomTools.framework/StudyroomTools'))
        changed = add_library(original.read(main))
        output.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as dest:
            for item in original.infolist():
                if item.filename.startswith(root + '_CodeSignature/'):
                    continue
                if item.filename.startswith(root + 'Frameworks/StudyroomTools.framework/'):
                    raise ValueError('Unexpected pre-existing add-on')
                dest.writestr(item, changed if item.filename == main else original.read(item))
            for name in names:
                if name.endswith('/'):
                    continue
                item = zipfile.ZipInfo(root + 'Frameworks/' + name)
                item.create_system = 3
                mode = 0o100755 if name == 'StudyroomTools.framework/StudyroomTools' else 0o100644
                item.external_attr = mode << 16
                item.compress_type = zipfile.ZIP_DEFLATED
                dest.writestr(item, addon.read(name))
    with zipfile.ZipFile(source) as original, zipfile.ZipFile(output) as result:
        assert result.testzip() is None
        modified = [name for name in result.namelist()
                    if name in original.namelist() and result.read(name) != original.read(name)]
        assert modified == [main], modified
        assert result.read(main) == changed
        removed = sorted(set(original.namelist()) - set(result.namelist()))
        assert all(name.startswith(root + '_CodeSignature/') for name in removed)
    report = {
        'sourceSHA256': hashlib.sha256(source.read_bytes()).hexdigest(),
        'outputSHA256': hashlib.sha256(output.read_bytes()).hexdigest(),
        'output': str(output.resolve()), 'originalFilesModified': modified,
        'removed': removed, 'archiveCRCValid': True,
        'executableSectionsUnchanged': True, 'requiresResigning': True,
        'phoneRuntimeTested': False,
        'note': 'Adds a separate Studyroom panel in the original app. No Gizmo chat, authentication, purchase or subscription logic modified.'
    }
    output.with_suffix('.verification.json').write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('original', type=Path)
    parser.add_argument('framework_zip', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    package(args.original, args.framework_zip, args.output)

const assert=require('node:assert/strict');const C=require('../Web/core.js');
let n=0;function test(name,fn){fn();n++;console.log('PASS',name)}
test('term extraction preserves answers and ignores prose',()=>{assert.deepEqual(C.pairs('Mitosis: two identical cells\nNo separator\nATP :: energy carrier\nDNA\tgenetic material').map(c=>c.q),['Mitosis','ATP','DNA'])});
test('review deadlines survive suspended execution',()=>{assert.equal(C.remaining({running:true,deadline:160000},100000),60);assert.equal(C.remaining({running:true,deadline:160000},190000),0)});
test('paused timer remains fixed',()=>assert.equal(C.remaining({running:false,remaining:321},9000000),321));
test('spaced repetition retries and advances correctly',()=>{let c={q:'Q',a:'A',interval:2};assert.equal(C.schedule(c,0,0).due,600000);assert.equal(C.schedule(c,2,0).due,4*86400000);assert.equal(C.schedule(c,3,0).interval,6)});
test('quiz includes correct answer exactly once',()=>{let cards=Array.from({length:8},(_,i)=>({q:'Q'+i,a:'A'+i,id:''+i}));let q=C.makeQuiz(cards,5);assert.equal(q.length,5);q.forEach(x=>{assert.equal(x.choices.length,4);assert.equal(x.choices.filter(c=>c===x.a).length,1)})});
test('exam plan includes test day and cycles topics',()=>{let p=C.planDays(['DNA','Cells'],'2026-10-20',25,new Date('2026-10-17T12:00:00'));assert.equal(p.length,4);assert.equal(p[0].day,'2026-10-17');assert.equal(p.at(-1).day,'2026-10-20');assert.match(p.at(-1).title,/Review/)});
test('streak allows today not completed yet',()=>assert.equal(C.streak([{day:'2026-10-15'},{day:'2026-10-16'}],new Date('2026-10-17T12:00:00')),2));
test('invalid backups are refused',()=>{assert.equal(!!C.validateBackup({version:1}),false);assert.equal(!!C.validateBackup({version:1,notes:[{id:'a',title:'b',body:'c'}],cards:[],tasks:[],sessions:[],results:[],chats:[]}),true)});
console.log(n+' tests passed');

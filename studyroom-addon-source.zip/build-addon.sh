#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
SDK_PATH="$(xcrun --sdk iphoneos --show-sdk-path)"
OUT_DIR="$PWD/dist/StudyroomTools.framework"
mkdir -p "$OUT_DIR/Web" build
xcrun --sdk iphoneos clang -fobjc-arc -target arm64-apple-ios16.4 \
  -isysroot "$SDK_PATH" -c Sources/Loader.m -o build/Loader.o
xcrun --sdk iphoneos swiftc -swift-version 5 -O \
  -target arm64-apple-ios16.4 -sdk "$SDK_PATH" \
  -emit-library -module-name StudyroomTools \
  -Xlinker -install_name -Xlinker '@rpath/StudyroomTools.framework/StudyroomTools' \
  -framework UIKit -framework WebKit -framework SwiftUI -framework PDFKit \
  -framework Vision -framework AVFoundation -framework Security -framework UserNotifications \
  Sources/Launcher.swift Sources/StudyController.swift build/Loader.o \
  -o "$OUT_DIR/StudyroomTools"
cp Web/* "$OUT_DIR/Web/"
cat > "$OUT_DIR/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleExecutable</key><string>StudyroomTools</string>
<key>CFBundleIdentifier</key><string>app.studyroom.gizmo.tools</string>
<key>CFBundleName</key><string>StudyroomTools</string>
<key>CFBundlePackageType</key><string>FMWK</string>
<key>CFBundleShortVersionString</key><string>1.0</string>
<key>CFBundleVersion</key><string>1</string>
<key>MinimumOSVersion</key><string>16.4</string>
<key>CFBundleSupportedPlatforms</key><array><string>iPhoneOS</string></array>
</dict></plist>
PLIST
plutil -lint "$OUT_DIR/Info.plist"
otool -L "$OUT_DIR/StudyroomTools"
nm -gU "$OUT_DIR/StudyroomTools" | grep StudyroomToolsLauncher
(cd dist && zip -qr StudyroomTools-framework.zip StudyroomTools.framework)
shasum -a 256 dist/StudyroomTools-framework.zip

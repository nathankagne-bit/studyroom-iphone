import UIKit
import WebKit

final class StudyroomMessageProxy: NSObject, WKScriptMessageHandler {
    weak var target: WKScriptMessageHandler?
    init(_ target: WKScriptMessageHandler) { self.target = target }
    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        target?.userContentController(controller, didReceive: message)
    }
}

@objc(StudyroomToolsLauncher)
public final class StudyroomToolsLauncher: NSObject {
    private static var observers: [NSObjectProtocol] = []
    private static var windows: [String: StudyroomWindow] = [:]

    @objc public static func install() {
        guard Thread.isMainThread else {
            DispatchQueue.main.async { install() }; return
        }
        if observers.isEmpty {
            for name in [UIApplication.didBecomeActiveNotification,
                         UIScene.didActivateNotification,
                         UIWindow.didBecomeVisibleNotification] {
                observers.append(NotificationCenter.default.addObserver(forName: name, object: nil, queue: .main) { _ in attach() })
            }
            observers.append(NotificationCenter.default.addObserver(forName: UIScene.didDisconnectNotification, object: nil, queue: .main) { notice in
                if let scene = notice.object as? UIWindowScene {
                    windows.removeValue(forKey: scene.session.persistentIdentifier)
                }
            })
        }
        attach()
    }

    private static func attach() {
        for case let scene as UIWindowScene in UIApplication.shared.connectedScenes {
            guard scene.activationState != .background,
                  scene.activationState != .unattached,
                  scene.windows.contains(where: { !($0 is StudyroomWindow) && !$0.isHidden && $0.rootViewController != nil }) else { continue }
            let id = scene.session.persistentIdentifier
            guard windows[id] == nil else { continue }
            let window = StudyroomWindow(windowScene: scene)
            // Register before showing: visibility notifications are synchronous.
            windows[id] = window
            window.rootViewController = StudyroomOverlayController()
            window.backgroundColor = .clear
            window.windowLevel = .normal + 2
            window.isHidden = false
        }
    }
}

private final class StudyroomWindow: UIWindow {
    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        let hit = super.hitTest(point, with: event)
        // The rest of Gizmo remains touchable outside the floating button.
        return hit === rootViewController?.view ? nil : hit
    }
}

private final class StudyroomOverlayController: UIViewController {
    private let button = UIButton(type: .system)
    private weak var previousKeyWindow: UIWindow?
    private var panel: UINavigationController?

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .clear
        var config = UIButton.Configuration.filled()
        config.title = "Studyroom"
        config.image = UIImage(systemName: "book.closed.fill")
        config.imagePadding = 7
        config.baseBackgroundColor = UIColor(red: 0.48, green: 0.24, blue: 0.87, alpha: 1)
        config.baseForegroundColor = .white
        config.cornerStyle = .capsule
        config.contentInsets = NSDirectionalEdgeInsets(top: 12, leading: 15, bottom: 12, trailing: 15)
        button.configuration = config
        button.accessibilityIdentifier = "studyroom-addon-open"
        button.accessibilityHint = "Opens your study tools. Drag to reposition."
        button.addTarget(self, action: #selector(openTools), for: .touchUpInside)
        button.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(moveButton(_:))))
        view.addSubview(button)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        button.sizeToFit()
        let area = view.safeAreaLayoutGuide.layoutFrame.insetBy(dx: 10, dy: 10)
        let defaults = UserDefaults.standard
        if defaults.object(forKey: "studyroom-addon-button-x") != nil {
            button.center = CGPoint(x: view.bounds.width * defaults.double(forKey: "studyroom-addon-button-x"),
                                    y: view.bounds.height * defaults.double(forKey: "studyroom-addon-button-y"))
        } else {
            button.center = CGPoint(x: area.maxX - button.bounds.width / 2,
                                    y: max(area.midY, area.maxY - button.bounds.height / 2 - 75))
        }
        clampButton()
    }

    private func clampButton() {
        let area = view.safeAreaLayoutGuide.layoutFrame.insetBy(dx: 8, dy: 8)
        button.center.x = min(max(button.center.x, area.minX + button.bounds.width / 2), area.maxX - button.bounds.width / 2)
        button.center.y = min(max(button.center.y, area.minY + button.bounds.height / 2), area.maxY - button.bounds.height / 2)
    }

    @objc private func moveButton(_ gesture: UIPanGestureRecognizer) {
        let change = gesture.translation(in: view)
        button.center.x += change.x; button.center.y += change.y
        gesture.setTranslation(.zero, in: view)
        clampButton()
        if gesture.state == .ended {
            UserDefaults.standard.set(button.center.x / max(1, view.bounds.width), forKey: "studyroom-addon-button-x")
            UserDefaults.standard.set(button.center.y / max(1, view.bounds.height), forKey: "studyroom-addon-button-y")
        }
    }

    @objc private func openTools() {
        guard presentedViewController == nil, let window = view.window else { return }
        previousKeyWindow = window.windowScene?.windows.first(where: { $0.isKeyWindow && $0 !== window })
        window.makeKey()
        let tools = StudyController()
        tools.title = "Studyroom"
        tools.edgesForExtendedLayout = []
        tools.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Back to Gizmo", style: .done, target: self, action: #selector(closeTools))
        let nav = UINavigationController(rootViewController: tools)
        nav.overrideUserInterfaceStyle = .dark
        nav.modalPresentationStyle = .fullScreen
        nav.navigationBar.tintColor = UIColor(red: 0.72, green: 0.54, blue: 1, alpha: 1)
        panel = nav
        present(nav, animated: true)
    }

    @objc private func closeTools() {
        dismiss(animated: true) { [weak self] in
            guard let self else { return }
            self.panel = nil
            self.previousKeyWindow?.makeKey()
        }
    }
}

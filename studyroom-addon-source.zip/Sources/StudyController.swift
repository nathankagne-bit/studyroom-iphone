import SwiftUI
import WebKit
import UniformTypeIdentifiers
import PDFKit
import Vision
import AVFoundation
import Security
import UserNotifications

struct TrackerView: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> StudyController { StudyController() }
    func updateUIViewController(_ uiViewController: StudyController, context: Context) {}
}
final class StudyController: UIViewController, WKScriptMessageHandler, UIDocumentPickerDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate, WKNavigationDelegate {
    var web: WKWebView!
    var pickerID = ""
    let speaker = AVSpeechSynthesizer()
    var trustedIndex: URL? { Bundle(for: StudyController.self).url(forResource: "index", withExtension: "html", subdirectory: "Web") }
    let stateURL = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("StudyroomAddon", isDirectory:true).appendingPathComponent("state.json")
    override func viewDidLoad() {
        super.viewDidLoad()
        let content = WKUserContentController(); content.add(StudyroomMessageProxy(self), name: "native")
        let config = WKWebViewConfiguration(); config.userContentController = content; config.websiteDataStore = .nonPersistent()
        web = WKWebView(frame: .zero, configuration: config); web.navigationDelegate = self
        web.scrollView.contentInsetAdjustmentBehavior = .never
        web.isOpaque=false; web.backgroundColor=UIColor(red:13/255,green:11/255,blue:20/255,alpha:1); web.scrollView.backgroundColor=web.backgroundColor
        view = web
        if let url = trustedIndex {
            web.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
        }
    }
    func respond(_ id: String, _ result: [String: Any]) {
        guard let data = try? JSONSerialization.data(withJSONObject: ["id":id,"result":result]), let json = String(data:data,encoding:.utf8) else { return }
        DispatchQueue.main.async { self.web.evaluateJavaScript("window.nativeReply(\(json))", completionHandler:nil) }
    }
    func key(_ new: String? = nil, service: String = "app.studyroom.gizmo.addon.ai") -> String {
        let query: [String:Any] = [kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:service,kSecAttrAccount as String:"provider"]
        if let value = new {
            SecItemDelete(query as CFDictionary)
            if !value.isEmpty { var q=query; q[kSecValueData as String]=Data(value.utf8); q[kSecAttrAccessible as String]=kSecAttrAccessibleWhenUnlockedThisDeviceOnly; SecItemAdd(q as CFDictionary,nil) }
            return value
        }
        var q=query; q[kSecReturnData as String]=true; q[kSecMatchLimit as String]=kSecMatchLimitOne
        var item: CFTypeRef?; let status=SecItemCopyMatching(q as CFDictionary,&item)
        guard status == errSecSuccess, let data=item as? Data else { return "" }; return String(data:data,encoding:.utf8) ?? ""
    }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.frameInfo.isMainFrame, let source = message.frameInfo.request.url,
              source.isFileURL, source.standardizedFileURL.path == trustedIndex?.standardizedFileURL.path,
              let body=message.body as? [String:Any], let id=body["id"] as? String, let action=body["action"] as? String else { return }
        let args=body["args"] as? [String:Any] ?? [:]
        switch action {
        case "load":
            let text=(try? String(contentsOf:stateURL,encoding:.utf8)) ?? ""
            respond(id,["text":text,"hasKey":!key().isEmpty,"hasCanvasKey":!key(service:"app.studyroom.gizmo.addon.canvas").isEmpty])
        case "save":
            do {
                guard let text=args["text"] as? String, text.utf8.count < 20_000_000 else { throw NSError(domain:"Invalid or oversized save",code:1) }
                try FileManager.default.createDirectory(at:stateURL.deletingLastPathComponent(),withIntermediateDirectories:true)
                try Data(text.utf8).write(to:stateURL,options:[.atomic,.completeFileProtectionUntilFirstUserAuthentication])
                respond(id,["ok":true])
            } catch { respond(id,["error":"Could not save: \(error.localizedDescription)"]) }
        case "key": _ = key(args["value"] as? String ?? ""); respond(id,["ok":true])
        case "import":
            pickerID=id
            let picker=UIDocumentPickerViewController(forOpeningContentTypes:[.pdf,.plainText,.commaSeparatedText,.json,.image],asCopy:true)
            picker.delegate=self; present(picker,animated:true)
        case "camera":
            pickerID=id
            guard UIImagePickerController.isSourceTypeAvailable(.camera) else { respond(id,["error":"Camera unavailable. Import an image from Files instead."]); return }
            let picker=UIImagePickerController(); picker.sourceType = .camera; picker.delegate=self; present(picker,animated:true)
        case "export":
            guard let text=args["text"] as? String else { return }
            let file=FileManager.default.temporaryDirectory.appendingPathComponent("Studyroom-backup.json")
            do { try text.write(to:file,atomically:true,encoding:.utf8); let share=UIActivityViewController(activityItems:[file],applicationActivities:nil); share.popoverPresentationController?.sourceView=view; present(share,animated:true); respond(id,["ok":true]) } catch { respond(id,["error":error.localizedDescription]) }
        case "speak":
            speaker.stopSpeaking(at:.immediate); let speech=AVSpeechUtterance(string:String((args["text"] as? String ?? "").prefix(12000))); speaker.speak(speech); respond(id,["ok":true])
        case "stopSpeak": speaker.stopSpeaking(at:.immediate); respond(id,["ok":true])
        case "notify":
            let seconds=args["seconds"] as? Double ?? 0
            let center=UNUserNotificationCenter.current(); center.removePendingNotificationRequests(withIdentifiers:["studyroom-addon-focus"])
            if seconds <= 0 { respond(id,["ok":true]); return }
            center.requestAuthorization(options:[.alert,.sound]) { allowed,_ in
                if allowed {
                    let content=UNMutableNotificationContent(); content.title="Focus session complete"; content.body="You did the work. Take a break and save your session."; content.sound = .default
                    center.add(UNNotificationRequest(identifier:"studyroom-addon-focus",content:content,trigger:UNTimeIntervalNotificationTrigger(timeInterval:max(1,seconds),repeats:false)))
                }
                self.respond(id,["ok":allowed])
            }
        case "canvasKey": _ = key(args["value"] as? String ?? "", service:"app.studyroom.gizmo.addon.canvas"); respond(id,["ok":true])
        case "canvasSync": canvasSync(id,args)
        case "openCanvas":
            if let raw=args["url"] as? String, let url=URL(string:raw), url.scheme == "https", let host=url.host, host.hasSuffix(".instructure.com") {
                var parts=URLComponents(url:url,resolvingAgainstBaseURL:false); parts?.scheme="canvas-courses"
                if let deep=parts?.url { UIApplication.shared.open(deep,options:[:]) { ok in if !ok { UIApplication.shared.open(url) } } }
                respond(id,["ok":true])
            } else { respond(id,["error":"Invalid Canvas link."]) }
        case "ai": ai(id,args)
        default: respond(id,["error":"Unknown operation"])
        }
    }
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) { respond(pickerID,["cancelled":true]) }
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls:[URL]) {
        guard let url=urls.first else { return }; let id=pickerID
        let scoped=url.startAccessingSecurityScopedResource(); defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        do {
            let data=try Data(contentsOf:url); guard data.count < 20_000_000 else { respond(id,["error":"Choose a file smaller than 20 MB."]); return }
            if url.pathExtension.lowercased() == "pdf" {
                guard let doc=PDFDocument(data:data) else { respond(id,["error":"Could not read this PDF."]); return }
                var text=""
                for i in 0..<min(doc.pageCount,100) { if let p=doc.page(at:i) { text += (p.string ?? "") + "\n" } }
                if text.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty { respond(id,["error":"This PDF contains scanned pages. Import a page as an image to scan its text."]) }
                else { respond(id,["name":url.deletingPathExtension().lastPathComponent,"text":String(text.prefix(150000))]) }
            } else if let image=UIImage(data:data) { recognize(image,id:id,name:url.deletingPathExtension().lastPathComponent) }
            else if let text=String(data:data,encoding:.utf8) { respond(id,["name":url.deletingPathExtension().lastPathComponent,"text":String(text.prefix(150000))]) }
            else { respond(id,["error":"Use a text PDF, UTF-8 text, CSV, JSON backup, or image."]) }
        } catch { respond(id,["error":error.localizedDescription]) }
    }
    func imagePickerControllerDidCancel(_ picker:UIImagePickerController) { picker.dismiss(animated:true); respond(pickerID,["cancelled":true]) }
    func imagePickerController(_ picker:UIImagePickerController,didFinishPickingMediaWithInfo info:[UIImagePickerController.InfoKey:Any]) {
        picker.dismiss(animated:true); if let image=info[.originalImage] as? UIImage { recognize(image,id:pickerID,name:"Scanned notes") }
    }
    func recognize(_ image:UIImage,id:String,name:String) {
        guard let cg=image.cgImage else { respond(id,["error":"Image could not be read."]); return }
        let request=VNRecognizeTextRequest { req,error in
            let text=(req.results as? [VNRecognizedTextObservation] ?? []).compactMap{$0.topCandidates(1).first?.string}.joined(separator:"\n")
            self.respond(id,text.isEmpty ? ["error":"No readable text found. Try a clearer photo."] : ["name":name,"text":text])
        }
        request.recognitionLevel = .accurate; request.usesLanguageCorrection=true
        DispatchQueue.global(qos:.userInitiated).async { do { try VNImageRequestHandler(cgImage:cg,options:[:]).perform([request]) } catch { self.respond(id,["error":error.localizedDescription]) } }
    }

    func canvasSync(_ id:String,_ args:[String:Any]) {
        guard let raw=args["host"] as? String, let base=URL(string:raw), base.scheme == "https", let host=base.host, host.hasSuffix(".instructure.com"), base.user == nil, base.password == nil, base.query == nil, base.fragment == nil, base.path.isEmpty || base.path == "/" else { respond(id,["error":"Use your school’s HTTPS Canvas address, such as https://yourschool.instructure.com."]); return }
        let token=key(service:"app.studyroom.gizmo.addon.canvas")
        guard !token.isEmpty else { respond(id,["error":"Add your Canvas access token first."]); return }
        Task {
            do {
                let courses=try await self.canvasPages(base.appendingPathComponent("api/v1/courses").absoluteString+"?enrollment_state=active&include[]=total_scores&per_page=100",host:host,token:token)
                var result:[[String:Any]]=[]; var warnings:[String]=[]
                for course in courses.prefix(30) {
                    guard let courseID=course["id"] as? Int else { continue }
                    let name=course["name"] as? String ?? "Course"
                    var assignments:[[String:Any]]=[]
                    do { assignments=try await self.canvasPages(base.appendingPathComponent("api/v1/courses/\(courseID)/assignments").absoluteString+"?include[]=submission&per_page=100",host:host,token:token) }
                    catch { warnings.append("\(name): assignments unavailable (\(error.localizedDescription))") }
                    let enrollments=course["enrollments"] as? [[String:Any]] ?? []
                    let grade=enrollments.first(where:{($0["type"] as? String)=="student"}) ?? enrollments.first ?? [:]
                    let tasks:[[String:Any]]=assignments.map { a in
                        let submission=a["submission"] as? [String:Any] ?? [:]
                        return ["id":a["id"] ?? 0,"title":a["name"] ?? "Assignment","due":a["due_at"] ?? NSNull(),"url":a["html_url"] ?? "","points":a["points_possible"] ?? NSNull(),"score":submission["score"] ?? NSNull(),"status":submission["workflow_state"] ?? "unsubmitted","missing":submission["missing"] ?? false,"late":submission["late"] ?? false]
                    }
                    result.append(["id":courseID,"name":name,"score":grade["computed_current_score"] ?? NSNull(),"letter":grade["computed_current_grade"] ?? NSNull(),"assignments":tasks])
                }
                self.respond(id,["courses":result,"warnings":warnings,"checkedAt":ISO8601DateFormatter().string(from:Date())])
            } catch { self.respond(id,["error":error.localizedDescription]) }
        }
    }
    func canvasPages(_ first:String,host:String,token:String) async throws -> [[String:Any]] {
        var next:String?=first; var items:[[String:Any]]=[]
        for _ in 0..<30 {
            guard let raw=next, let url=URL(string:raw), url.scheme == "https", url.host == host else { break }
            var request=URLRequest(url:url); request.timeoutInterval=30; request.setValue("Bearer \(token)",forHTTPHeaderField:"Authorization")
            let (data,response)=try await URLSession.shared.data(for:request)
            guard let http=response as? HTTPURLResponse else { throw NSError(domain:"No Canvas response",code:1) }
            guard http.url?.host == host else { throw NSError(domain:"Canvas redirected to another host; check the school address",code:1) }
            guard (200..<300).contains(http.statusCode) else { throw NSError(domain:http.statusCode==401 ? "Canvas rejected the token. Check that it is valid and not expired" : "Canvas returned \(http.statusCode)",code:http.statusCode) }
            guard let rows=(try JSONSerialization.jsonObject(with:data)) as? [[String:Any]] else { throw NSError(domain:"Canvas returned an unexpected response",code:1) }
            items.append(contentsOf:rows); next=nil
            let link=http.value(forHTTPHeaderField:"Link") ?? ""
            for part in link.components(separatedBy:",") where part.contains("rel=\"next\"") {
                if let start=part.firstIndex(of:"<"), let end=part.firstIndex(of:">") { next=String(part[part.index(after:start)..<end]) }
            }
            if next == nil { return items }
        }
        if next != nil { throw NSError(domain:"Canvas returned too many pages. Data was not replaced",code:1) }
        return items
    }

    func ai(_ id:String,_ args:[String:Any]) {
        guard let raw=args["endpoint"] as? String, let base=URL(string:raw), base.scheme == "https", base.host != nil,
              base.user == nil, base.password == nil, base.query == nil, base.fragment == nil else { respond(id,["error":"Use an HTTPS provider base URL, without credentials or query strings."]); return }
        let url=base.appendingPathComponent("chat/completions")
        var req=URLRequest(url:url); req.httpMethod="POST"; req.timeoutInterval=120
        req.setValue("application/json",forHTTPHeaderField:"Content-Type")
        let token=key(); if !token.isEmpty { req.setValue("Bearer \(token)",forHTTPHeaderField:"Authorization") }
        let payload:[String:Any] = ["model":args["model"] as? String ?? "", "messages":args["messages"] as? [[String:Any]] ?? [], "max_completion_tokens":4000]
        do { req.httpBody=try JSONSerialization.data(withJSONObject:payload) } catch { respond(id,["error":"Could not prepare request."]); return }
        URLSession.shared.dataTask(with:req) { data,response,error in
            if let error=error { self.respond(id,["error":error.localizedDescription]); return }
            guard let http=response as? HTTPURLResponse, let data=data else { self.respond(id,["error":"No response from provider."]); return }
            guard (200..<300).contains(http.statusCode) else { self.respond(id,["error":"Provider returned \(http.statusCode). Check your key, model, and available quota."]); return }
            guard let object=(try? JSONSerialization.jsonObject(with:data)) as? [String:Any], let choices=object["choices"] as? [[String:Any]], let message=choices.first?["message"] as? [String:Any], let content=message["content"] as? String, !content.isEmpty else { self.respond(id,["error":"The provider returned no answer."]); return }
            self.respond(id,["text":content])
        }.resume()
    }
    func webView(_ webView:WKWebView,decidePolicyFor navigationAction:WKNavigationAction,decisionHandler:@escaping(WKNavigationActionPolicy)->Void) {
        if let url=navigationAction.request.url, url.isFileURL || url.scheme == "about" || url.scheme == "blob" { decisionHandler(.allow) } else { decisionHandler(.cancel) }
    }
}

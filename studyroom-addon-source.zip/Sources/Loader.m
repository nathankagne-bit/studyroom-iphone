#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

// Add an independent interface after UIApplication has started. No hooks into
// Gizmo methods, authentication, purchases, network requests, or chat storage.
__attribute__((constructor)) static void StudyroomToolsLoad(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        Class launcher = NSClassFromString(@"StudyroomToolsLauncher");
        SEL selector = NSSelectorFromString(@"install");
        if (launcher && [launcher respondsToSelector:selector]) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
            [launcher performSelector:selector];
#pragma clang diagnostic pop
        }
    });
}

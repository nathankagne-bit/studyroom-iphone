# Studyroom native add-on

Original Studyroom tools presented as a native panel inside an existing iPhone app. A movable purple Studyroom button opens the tools; Back to Gizmo dismisses them. This is an additive framework, not a replacement web wrapper or a modification of the host app's chat, authentication, network, or subscription functions.

Included from Studyroom: notes and classes; PDF text import; image OCR and camera scanning; editable flashcards and spaced recall; card quizzes and timed practice; exam planning, tasks, focus timer and completion notifications; progress; text-to-speech; JSON backup and restore; read-only Canvas course/assignment/grade import; optional AI tutoring and study-pack generation using the user's provider key.

Studyroom's AI uses a separately configured provider key and quota. It does not use Gizmo's AI account. No Gizmo conversation deletion, shared account storage, automatic extraction of Gizmo chats, or automatic migration from the standalone Studyroom app is included. Existing Studyroom backups can be imported manually. Canvas requires a school-issued personal access token and a school that permits its use.

The framework uses its own local state file and Keychain service names. Its web interface loads bundled files in a separate web view; the host app cannot invoke its native bridge. No account data or third-party app code belongs in this source archive.

## Build and packaging

Run `bash build-addon.sh` on a Mac with Xcode and the iPhone SDK, or use the included GitHub Actions workflow. This builds an unsigned arm64 iOS 16.4+ framework ZIP. It is not an IPA by itself.

After a successful build, run `python3 package_ipa.py ORIGINAL_IPA FRAMEWORK_ZIP OUTPUT_IPA` locally. The packager checks the expected Gizmo app identifier and header padding, adds one framework dependency, preserves executable sections and existing files, and produces a new unsigned IPA plus a verification report. The original IPA is not uploaded to GitHub and must not be overwritten. Re-sign the output with an installer before use.

## Verification status

Local Swift parsing, study logic checks, and in-memory Mach-O header verification are available before the cloud build. These do not confirm an iPhone build, successful loading in Gizmo, login compatibility, camera access, actual Canvas sync, notifications, or physical-device interaction. Compilation and installed-app testing remain required.

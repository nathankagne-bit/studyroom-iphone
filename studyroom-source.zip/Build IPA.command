#!/bin/bash
set -euo pipefail

studyroom_root="$(cd "$(dirname "$0")" && pwd)"
cd "$studyroom_root"

studyroom_finish() {
    if [ -t 0 ]; then
        printf '\nPress Return to close this window.\n'
        read -r _ || true
    fi
}
trap studyroom_finish EXIT

if [ -d /Applications/Xcode.app/Contents/Developer ]; then
    export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
fi
if ! /usr/bin/xcrun --find xcodebuild >/dev/null 2>&1; then
    printf 'Install Xcode from the Mac App Store and open it once to finish setup.\n'
    exit 1
fi
if ! /usr/bin/xcrun --sdk iphoneos --show-sdk-path >/dev/null 2>&1; then
    printf 'Open Xcode and install its iOS platform support, then try again.\n'
    exit 1
fi

printf 'Building the iPhone app. This can take a few minutes…\n'
/usr/bin/xcrun xcodebuild \
    -project Studyroom.xcodeproj \
    -scheme Studyroom \
    -configuration Release \
    -sdk iphoneos \
    -destination 'generic/platform=iOS' \
    -derivedDataPath "$studyroom_root/build/DerivedData" \
    CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO \
    build

studyroom_app="$studyroom_root/build/DerivedData/Build/Products/Release-iphoneos/Studyroom.app"
studyroom_executable="$(/usr/libexec/PlistBuddy -c 'Print CFBundleExecutable' "$studyroom_app/Info.plist")"
if ! /usr/bin/file "$studyroom_app/$studyroom_executable" | /usr/bin/grep -q 'Mach-O.*arm64'; then
    printf 'The expected iPhone executable was not built. No IPA created.\n'
    exit 1
fi
studyroom_platform="$(/usr/libexec/PlistBuddy -c 'Print CFBundleSupportedPlatforms:0' "$studyroom_app/Info.plist")"
if [ "$studyroom_platform" != iPhoneOS ]; then
    printf 'This is not an iPhone device build. No IPA created.\n'
    exit 1
fi

studyroom_package="$(/usr/bin/mktemp -d "$studyroom_root/build/package.XXXXXX")"
/bin/mkdir "$studyroom_package/Payload"
/usr/bin/ditto "$studyroom_app" "$studyroom_package/Payload/Studyroom.app"
/bin/mkdir -p "$studyroom_root/dist"
/bin/rm -f "$studyroom_root/dist/Studyroom-unsigned.ipa"
/usr/bin/ditto -c -k --keepParent "$studyroom_package/Payload" "$studyroom_root/dist/Studyroom-unsigned.ipa"
/bin/rm -rf "$studyroom_package"
printf '\nCreated: %s/dist/Studyroom-unsigned.ipa\nUse your installer to sign and install this IPA.\n' "$studyroom_root"
if [ "${CI:-}" != true ]; then
    /usr/bin/open "$studyroom_root/dist"
fi

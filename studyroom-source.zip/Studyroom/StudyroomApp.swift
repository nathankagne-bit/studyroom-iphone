import SwiftUI

@main
struct StudyroomApp: App {
    var body: some Scene {
        WindowGroup {
            TrackerView()
                .preferredColorScheme(.dark)
        }
    }
}

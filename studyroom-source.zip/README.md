# Studyroom 1.0 — iPhone source

An original purple-and-black offline-first study app. Bundle identifier: app.studyroom.personal. iOS 16+.

Implemented: local notes by class, PDF text and image OCR import, camera scanning, text-to-speech, editable flashcards, scheduled recall, quizzes and timed practice tests from your cards, exam study plans, tasks, focus timer with persisted deadline and optional native notification, progress, JSON backup export/restore. AI tutoring and note-to-study-pack generation require your own compatible HTTPS provider and explicit consent; no provider or paid quota is included.

The core works without a server. Data stays in Application Support on this device, API keys in Keychain. No automatic cloud data sync or Knowunity library. Image OCR extracts readable text; it is not a mathematical image reasoning service. Scanned PDFs must be imported as page images. Slides, YouTube processing, live voice conversation, social leagues, official SAT/AP formats, community library, and cloud sync are not implemented in this first build.

Build: bash 'Build IPA.command' on a Mac with full Xcode+iOS SDK, or run the supplied GitHub Actions workflow. Output: dist/Studyroom-unsigned.ipa. Sign it using your existing Sideloadly account. No Apple credentials are used in the build. Export a backup before reinstalling or changing signing account.

Verification: local core tests and JavaScript/Swift syntax checks are separate from a successful iPhone compilation. Physical-device camera, Keychain, notifications, and locked-screen testing require the installed IPA.

Canvas: read-only course, assignment, due-date and published grade sync through the school Canvas API. Your personal token stays in a separate Keychain item. Canvas must allow personal token access; this has not been tested with a real school account. Missing/hidden grades are displayed as unavailable, never zero. Assignment links try Canvas Student then the browser. No submission endpoints are called.
